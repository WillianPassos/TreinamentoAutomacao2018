#encoding: utf-8

Dado("que eu esteja no site do google para criar um e-mail") do                             
  visit(@url)               
end                                                                                         

Quando("preencho todos os campos do formulario e clico no botão próxima etapa") do |table|
  @cadastro = CadastroPage.new
  @nome = table.rows_hash['Nome']
  @sobrenome = table.rows_hash['Sobrenome']
  @usuario = table.rows_hash['usuário']
  @senha = table.rows_hash['senha']
  @confirmar_senha = table.rows_hash['confirmarSenha']
  @dia_nascimento = table.rows_hash['diaNascimento']

  @cadastro.cadastro_google(@nome,@sobrenome,@usuario,@senha,
                            @confirmar_senha)  
end
                                                                                           
Então("eu vejo a próxima tela para Verifique seu número de telefone") do                    
  expect(page).to have_content 'Verifique seu número de telefone'               
end                                                                                         